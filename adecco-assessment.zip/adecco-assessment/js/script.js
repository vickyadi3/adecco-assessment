(() => {
	window.addEventListener('DOMContentLoaded', () => {
        generateRandomCard('sort');
        const shuffleBtn = document.querySelector('.shuffle-button'),
            sortBtn = document.querySelector('.sort-button');

		shuffleBtn.addEventListener('click', () => {
			generateRandomCard('random');
		});
		sortBtn.addEventListener('click', () => {
			generateRandomCard('sort');
		});		
	});
	
	const generateRandomCard = (mode) => {
        const count = 9;
		let randomCard = '',
			tempValue = [],
			number = 0;
		// While there remain elements to shuffle...
		while(tempValue.length < count){
			(mode === 'sort') ? number = tempValue.length + 1 : number = (Math.ceil(Math.random() * count));
			// Pick a remaining element...
			if(tempValue.indexOf(number) === -1 ) {
				randomCard += '<div class="card card_' + number + '">' + number + '</div>';
				tempValue.push(number);
			}
		}
		document.querySelector('.randomCard-container').innerHTML = randomCard;
	}
})();